# Engaggio — Full-Stack Starter

A minimal, **working** implementation of the walking skeleton described in
`Engaggio_AI_Construction_Platform_Technical_Specification_Ver_1_0.pdf`:

```
Upload document → Register → Process (extract → classify → calculate) → BOQ
```

This is a starting point, not the full platform. It implements one real,
runnable path end to end — tenant provisioning, auth, project/document
management, a background processing pipeline, and a deterministic BOQ & cost
engine — using the exact API contracts and data model from the spec (sections
9, 12, 13). Everything else in the spec (CAD/BIM adapters, real ML
classification, BBS, planning, revision comparison, dashboards) is a module
to be added into this same architecture.

## What's real vs. stubbed

| Layer | Status |
|---|---|
| Multi-tenant auth (JWT), tenant isolation | Real |
| Project / document CRUD, file upload + checksum | Real |
| Async job pipeline & state machine (spec §8) | Real (in-process background task; swap for Celery/RQ + a queue in production) |
| BOQ & Cost Engine (deterministic quantity × rate) | Real |
| **Final estimate** (overhead/profit/contingency/tax cascade) | Real — `services/cost_summary.py`. The BOQ total alone is only the direct cost; `GET /api/v1/projects/{id}/cost-summary` applies the markup cascade to produce the actual quoted grand total, shown in the project page's "Final Estimate" panel. |
| **Vector PDF extraction & classification** (spec §6.4–6.5) | **Real** — `backend/app/services/extraction_pdf.py` parses actual geometry and text from the PDF using PyMuPDF, converts to real-world units via the drawing's plot scale, and classifies elements with deterministic label-matching + geometry-fallback rules. See "Accuracy & limitations" below. |
| DWG/DXF, IFC, scanned/raster PDF extraction | **Not implemented.** Falls back to an obviously-flagged placeholder (confidence 0.0, `source_reference` prefixed "UNSUPPORTED FORMAT") — never silently treated as real data. |
| BBS, Planning, Revision Comparison (spec §6.8–6.10) | Not implemented — same pattern as BOQ engine, add as new services + routers |

## Checking detections against the drawing

On the project page, **CHECK ON DRAWING** (per PDF document) renders the
actual sheet with every detected element boxed and numbered — green ≥ 80%,
amber 50–80%, red < 50% (not priced) — next to a table with the same
numbers, so each detection can be verified by eye. Backed by
`GET /api/v1/jobs/{id}/overlay?page=N`.

Real sheets are full of non-element vector content. The extractor ignores
the sheet border, double borders, stroked duplicate outlines, symbol-sized
marks (hatch ticks, arrowheads, < 0.02 m² at plot scale), and large unlabeled
unfilled boxes (title blocks, viewports). Each run's job message states how
many shapes were read and how many of each kind were ignored.
`backend/test_generate_noisy_pdf.py` builds a cluttered test sheet to show this.

## Accuracy & limitations of the PDF extractor — read this before relying on it

This does real, deterministic parsing of the PDF's actual vector paths and
text — it is not guessing with an LLM. Given a correctly-scaled, well-labeled
vector PDF, it produces accurate quantities. But "accurate" depends on two
things that are your responsibility, not the software's:

1. **The plot scale you enter must match the sheet.** Unit conversion is
   exact arithmetic once the scale is right, and wrong once it isn't.
2. **Text labels need to sit near their own element**, not equidistant
   between two elements or floating alone. Standard drafting practice
   already does this. When a shape has no nearby label, it's classified by
   geometry alone (aspect ratio / size) and is *deliberately* given low
   confidence — see below.

**Every element below 80% confidence is excluded from the BOQ automatically**
and appears in the project page's "Needs review" panel instead of a client
number. Nothing enters a BOQ un-reviewed just because the software guessed
at it. This is what makes the output trustworthy — not a claim that
extraction is error-free (no CAD/BIM extraction system, from any vendor,
can honestly claim that), but that uncertain items never masquerade as
certain ones.

**What will still need a human:** rotated/curved elements (the parser
approximates paths by bounding box, which is accurate for rectangular
plan-view walls/columns/slabs but not for angled or curved members),
overlapping elements at the same location (e.g. a footing directly under
a column in plan view — indistinguishable by position alone), and any PDF
where CAD software didn't export clean vector geometry (a "flattened" or
image-based export needs the raster/OCR path, which isn't built here).

## Stack

- **Backend**: FastAPI, SQLAlchemy, SQLite (swap `DATABASE_URL` for Postgres in production), JWT auth, background tasks
- **Frontend**: Next.js 14 (App Router), TypeScript, Tailwind

## Run locally

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
# → http://localhost:8000/docs for interactive API docs
```

### Frontend
```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
# → http://localhost:3000
```

### Or with Docker
```bash
docker compose up --build
```

## Try it

1. Open `http://localhost:3000`, provision a tenant (signup).
2. Add BOQ catalogue items via `POST /api/v1/catalogue-items` (Swagger UI
   at `/docs` is easiest) with codes `BOQ-WALL-001`, `BOQ-COL-001`,
   `BOQ-SLAB-001`, `BOQ-BEAM-001`, `BOQ-FTG-001` — these are the default
   element→BOQ mapping the extractor uses (edit
   `services/boq_engine.py::DEFAULT_ELEMENT_TO_CODE` to match your own
   coding structure).
3. Create a project, upload a **vector PDF** (text/lines must be real PDF
   objects, not a scanned image — export "to scale" from AutoCAD/Revit/etc.,
   not "print to image"), set the plot scale to match the sheet, and submit.
4. Watch the job progress; when it finishes, the BOQ table populates and
   any low-confidence elements appear in "Needs review" instead.

No real drawing handy? `backend/test_generate_pdf.py` generates a synthetic
labeled floor plan (`/tmp/sample_floorplan.pdf`) at 1:100 scale you can
upload to see the pipeline work end to end — this is exactly how the
extraction engine was validated during development.

## Where to go next

- Add DWG/DXF (via `ezdxf`) and IFC (via `ifcopenshell`) adapters alongside
  `extraction_pdf.py`, following the same pattern: real geometry parsing +
  confidence-scored classification + low-confidence exclusion from BOQ
- Add a raster/OCR fallback (spec §6.4) for scanned drawings — expect
  materially lower confidence and a larger review queue, and say so in the UI
- Let a reviewer correct a misclassified element and re-run BOQ generation
  for just that element (spec §6.5, "human correction queue")
- Replace the in-process `BackgroundTasks` call in `routers/jobs.py` with a
  Celery/RQ worker reading from a real queue (spec §5 architecture diagram)
  — the job state machine and API shape already match §8, so this is a
  drop-in swap
- Add the BBS and Planning engines as new services following the same
  pattern as `services/boq_engine.py`
- Move file storage from local disk to S3/GCS-compatible object storage
- Add Alembic migrations once the schema stabilizes
