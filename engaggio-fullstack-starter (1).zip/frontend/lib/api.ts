const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export type Project = {
  id: string;
  name: string;
  location: string | null;
  project_type: string;
  units: string;
  currency: string;
  status: string;
  overhead_percent: string;
  profit_percent: string;
  contingency_percent: string;
  tax_percent: string;
  created_at: string;
};

export type CostSummary = {
  currency: string;
  direct_cost: string;
  overhead_percent: string;
  overhead_amount: string;
  subtotal_after_overhead: string;
  profit_percent: string;
  profit_amount: string;
  subtotal_after_profit: string;
  contingency_percent: string;
  contingency_amount: string;
  subtotal_after_contingency: string;
  tax_percent: string;
  tax_amount: string;
  grand_total: string;
};

export type Document = {
  id: string;
  project_id: string;
  file_name: string;
  discipline: string;
  document_number: string | null;
  revision: string;
  scale_ratio: number;
  status: string;
  uploaded_at: string;
};

export type Job = {
  id: string;
  document_id: string;
  status: string;
  progress: number;
  correlation_id: string;
  warnings: string;
  errors: string;
  updated_at: string;
};

export type Element = {
  id: string;
  element_class: string;
  quantity_type: string;
  value: string;
  unit: string;
  confidence: string;
  source_reference: string;
  matched_label: string | null;
  page_number: number | null;
};

export type BOQLine = {
  id: string;
  catalogue_item_id: string;
  element_id: string | null;
  quantity: string;
  rate: string;
  amount: string;
  status: string;
};

export type BOQSummary = {
  project_id: string;
  currency: string;
  line_count: number;
  total_amount: string;
  lines: BOQLine[];
};

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem("engaggio_token");
}

export function setToken(token: string) {
  window.localStorage.setItem("engaggio_token", token);
}

export function clearToken() {
  window.localStorage.removeItem("engaggio_token");
}

class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    ...((options.headers as Record<string, string>) || {}),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  if (!(options.body instanceof FormData) && options.body) {
    headers["Content-Type"] = "application/json";
  }

  const res = await fetch(`${API_URL}${path}`, { ...options, headers });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch {
      /* no-op */
    }
    throw new ApiError(res.status, detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export const api = {
  signup: (data: {
    tenant_name: string;
    admin_email: string;
    admin_full_name: string;
    password: string;
  }) =>
    request<{ access_token: string }>("/api/v1/auth/signup", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  login: async (email: string, password: string) => {
    const form = new URLSearchParams();
    form.set("username", email);
    form.set("password", password);
    const res = await fetch(`${API_URL}/api/v1/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    });
    if (!res.ok) throw new ApiError(res.status, "Invalid credentials");
    return res.json() as Promise<{ access_token: string }>;
  },

  me: () => request<{ email: string; full_name: string; role: string }>("/api/v1/auth/me"),

  listProjects: () => request<Project[]>("/api/v1/projects"),

  createProject: (data: {
    name: string;
    location?: string;
    project_type?: string;
    units?: string;
    currency?: string;
  }) =>
    request<Project>("/api/v1/projects", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  getProject: (id: string) => request<Project>(`/api/v1/projects/${id}`),

  listDocuments: (projectId: string) =>
    request<Document[]>(`/api/v1/projects/${projectId}/documents`),

  uploadDocument: (
    projectId: string,
    file: File,
    meta: { discipline: string; document_number: string; revision: string; scale_ratio: number }
  ) => {
    const form = new FormData();
    form.append("file", file);
    form.append("discipline", meta.discipline);
    form.append("document_number", meta.document_number);
    form.append("revision", meta.revision);
    form.append("scale_ratio", String(meta.scale_ratio));
    return request<Document>(`/api/v1/projects/${projectId}/documents`, {
      method: "POST",
      body: form,
    });
  },

  getJobReview: (jobId: string) =>
    request<Element[]>(`/api/v1/jobs/${jobId}/elements`).then((els) =>
      els.filter((e) => Number(e.confidence) < 0.8)
    ),

  processDocument: (documentId: string, outputs: string[]) =>
    request<Job>(`/api/v1/documents/${documentId}/process`, {
      method: "POST",
      body: JSON.stringify({ outputs }),
    }),

  getJob: (jobId: string) => request<Job>(`/api/v1/jobs/${jobId}`),

  getLatestJob: (documentId: string) =>
    request<Job>(`/api/v1/documents/${documentId}/jobs/latest`),

  // The overlay is an authenticated image, so it can't be a plain <img src>:
  // fetch it with the bearer token and hand back a blob URL plus page count.
  getOverlay: async (jobId: string, page: number) => {
    const token = getToken();
    const res = await fetch(`${API_URL}/api/v1/jobs/${jobId}/overlay?page=${page}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!res.ok) {
      let detail = res.statusText;
      try {
        detail = (await res.json()).detail || detail;
      } catch {
        /* no-op */
      }
      throw new ApiError(res.status, detail);
    }
    const blob = await res.blob();
    return {
      url: URL.createObjectURL(blob),
      pageCount: Number(res.headers.get("X-Page-Count") || 1),
    };
  },

  getJobElements: (jobId: string) =>
    request<Element[]>(`/api/v1/jobs/${jobId}/elements`),

  getProjectBOQ: (projectId: string) =>
    request<BOQSummary>(`/api/v1/projects/${projectId}/boq`),

  updateCostSettings: (
    projectId: string,
    settings: {
      overhead_percent: number;
      profit_percent: number;
      contingency_percent: number;
      tax_percent: number;
    }
  ) =>
    request<Project>(`/api/v1/projects/${projectId}/cost-settings`, {
      method: "PUT",
      body: JSON.stringify(settings),
    }),

  getCostSummary: (projectId: string) =>
    request<CostSummary>(`/api/v1/projects/${projectId}/cost-summary`),

  listCatalogueItems: () =>
    request<
      { id: string; code: string; description: string; unit: string; trade: string; rate: string; currency: string }[]
    >("/api/v1/catalogue-items"),

  createCatalogueItem: (data: {
    code: string;
    description: string;
    unit: string;
    trade: string;
    rate: number;
    currency: string;
  }) =>
    request(`/api/v1/catalogue-items`, {
      method: "POST",
      body: JSON.stringify(data),
    }),
};

export { ApiError };
