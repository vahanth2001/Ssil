import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#14171A",
        surface: "#1B2024",
        surface2: "#20262B",
        line: "#2C333A",
        paper: "#ECEEF0",
        muted: "#8B95A1",
        blueprint: "#4C8FBF",
        blueprintDim: "#2E4E63",
        amber: "#D08A3E",
        ok: "#57A583",
        danger: "#C05B4E",
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
    },
  },
  plugins: [],
};
export default config;
