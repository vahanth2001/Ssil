"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { clearToken } from "@/lib/api";

export default function TopBar({ crumb }: { crumb?: string }) {
  const router = useRouter();
  return (
    <header className="border-b border-line">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <div className="flex items-baseline gap-3">
          <Link href="/dashboard" className="font-display text-lg font-bold tracking-tight">
            ENGAGGIO
          </Link>
          <span className="mono-tag hidden sm:inline">AI CONSTRUCTION INTELLIGENCE</span>
          {crumb && (
            <>
              <span className="text-line">/</span>
              <span className="text-sm text-muted">{crumb}</span>
            </>
          )}
        </div>
        <button
          onClick={() => {
            clearToken();
            router.push("/login");
          }}
          className="mono-tag rounded border border-line px-3 py-1.5 text-paper hover:border-blueprint hover:text-blueprint transition-colors"
        >
          SIGN OUT
        </button>
      </div>
    </header>
  );
}
