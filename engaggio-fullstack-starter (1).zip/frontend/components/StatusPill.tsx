const STATUS_STYLES: Record<string, string> = {
  QUEUED: "bg-surface2 text-muted border-line",
  EXTRACTING: "bg-blueprintDim text-blueprint border-blueprint/40",
  CLASSIFYING: "bg-blueprintDim text-blueprint border-blueprint/40",
  CALCULATING: "bg-blueprintDim text-blueprint border-blueprint/40",
  REVIEW_REQUIRED: "bg-amber/10 text-amber border-amber/40",
  DRAFT_OUTPUT: "bg-ok/10 text-ok border-ok/40",
  COMPLETED: "bg-ok/10 text-ok border-ok/40",
  FAILED: "bg-danger/10 text-danger border-danger/40",
  REGISTERED: "bg-surface2 text-muted border-line",
  READY: "bg-ok/10 text-ok border-ok/40",
  Preliminary: "bg-amber/10 text-amber border-amber/40",
  Draft: "bg-surface2 text-muted border-line",
  Approved: "bg-ok/10 text-ok border-ok/40",
};

export default function StatusPill({ status }: { status: string }) {
  const cls = STATUS_STYLES[status] || "bg-surface2 text-muted border-line";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-mono tracking-wide ${cls}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {status.replaceAll("_", " ")}
    </span>
  );
}
