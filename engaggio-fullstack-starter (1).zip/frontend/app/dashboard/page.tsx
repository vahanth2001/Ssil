"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import TopBar from "@/components/TopBar";
import { api, Project, ApiError } from "@/lib/api";

export default function DashboardPage() {
  const router = useRouter();
  const [projects, setProjects] = useState<Project[] | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", location: "", currency: "USD" });
  const [error, setError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  async function load() {
    try {
      setProjects(await api.listProjects());
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        router.push("/login");
      } else {
        setError("Could not load projects");
      }
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    setError(null);
    try {
      await api.createProject(form);
      setForm({ name: "", location: "", currency: "USD" });
      setShowForm(false);
      await load();
    } catch {
      setError("Could not create project");
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="min-h-screen">
      <TopBar crumb="Projects" />
      <main className="mx-auto max-w-6xl px-6 py-10">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <div className="mono-tag mb-2">PROJECT REGISTER</div>
            <h1 className="font-display text-3xl font-bold tracking-tight">Projects</h1>
          </div>
          <button
            onClick={() => setShowForm((v) => !v)}
            className="rounded bg-blueprint px-4 py-2 text-sm font-medium text-ink hover:opacity-90"
          >
            {showForm ? "CANCEL" : "+ NEW PROJECT"}
          </button>
        </div>

        {showForm && (
          <form
            onSubmit={handleCreate}
            className="ledger-row mb-10 max-w-lg space-y-4 rounded-r-md bg-surface p-6"
            data-ref="NEW"
          >
            <div>
              <label className="mono-tag mb-1 block">PROJECT NAME</label>
              <input
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full rounded border border-line bg-ink px-3 py-2 text-sm outline-none focus:border-blueprint"
                placeholder="Vijayawada Compound Wall"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mono-tag mb-1 block">LOCATION</label>
                <input
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  className="w-full rounded border border-line bg-ink px-3 py-2 text-sm outline-none focus:border-blueprint"
                  placeholder="Vijayawada, AP"
                />
              </div>
              <div>
                <label className="mono-tag mb-1 block">CURRENCY</label>
                <select
                  value={form.currency}
                  onChange={(e) => setForm({ ...form, currency: e.target.value })}
                  className="w-full rounded border border-line bg-ink px-3 py-2 text-sm outline-none focus:border-blueprint"
                >
                  {["USD", "INR", "AED", "SAR"].map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </div>
            </div>
            {error && <p className="text-sm text-danger">{error}</p>}
            <button
              type="submit"
              disabled={creating}
              className="rounded bg-blueprint px-4 py-2 text-sm font-medium text-ink hover:opacity-90 disabled:opacity-50"
            >
              {creating ? "CREATING…" : "CREATE PROJECT"}
            </button>
          </form>
        )}

        {projects === null && <p className="text-muted">Loading…</p>}

        {projects?.length === 0 && (
          <div className="ledger-row rounded-r-md bg-surface p-8" data-ref="EMPTY">
            <p className="text-muted">
              No projects yet. Create one to register drawings and start extraction.
            </p>
          </div>
        )}

        <div className="space-y-3">
          {projects?.map((p) => (
            <Link
              key={p.id}
              href={`/projects/${p.id}`}
              className="ledger-row block rounded-r-md bg-surface p-5 transition-colors hover:bg-surface2"
              data-ref={p.id.slice(0, 8)}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-display text-lg font-medium">{p.name}</p>
                  <p className="mono-tag mt-1">
                    {p.location || "NO LOCATION"} · {p.currency} · {p.units.toUpperCase()}
                  </p>
                </div>
                <span className="mono-tag rounded-full border border-line px-3 py-1">
                  {p.status.toUpperCase()}
                </span>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}
