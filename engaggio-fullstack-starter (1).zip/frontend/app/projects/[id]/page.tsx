"use client";

import { useCallback, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import TopBar from "@/components/TopBar";
import StatusPill from "@/components/StatusPill";
import { api, Project, Document, Job, BOQSummary, Element, CostSummary, ApiError } from "@/lib/api";

function Row({ label, value, muted }: { label: string; value: string; muted?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className={muted ? "text-muted" : "text-paper"}>{label}</span>
      <span className={muted ? "text-muted" : "text-paper"}>
        {Number(value).toLocaleString()}
      </span>
    </div>
  );
}

export default function ProjectDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();

  const [project, setProject] = useState<Project | null>(null);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [boq, setBoq] = useState<BOQSummary | null>(null);
  const [activeJobs, setActiveJobs] = useState<Record<string, Job>>({});
  const [reviewQueue, setReviewQueue] = useState<Element[]>([]);
  const [costSummary, setCostSummary] = useState<CostSummary | null>(null);
  const [costForm, setCostForm] = useState({
    overhead_percent: 0,
    profit_percent: 0,
    contingency_percent: 0,
    tax_percent: 0,
  });
  const [savingCostSettings, setSavingCostSettings] = useState(false);
  const activeJobsByDoc: Record<string, Job> = {};
  Object.values(activeJobs).forEach((j) => (activeJobsByDoc[j.document_id] = j));
  const [check, setCheck] = useState<{
    docName: string;
    jobId: string;
    page: number;
    pageCount: number;
    url: string | null;
    elements: Element[];
    loading: boolean;
    error: string | null;
  } | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [meta, setMeta] = useState({
    discipline: "structural",
    document_number: "",
    revision: "A",
    scale_ratio: 100,
  });

  const load = useCallback(async () => {
    try {
      const [p, docs, boqSummary, cost] = await Promise.all([
        api.getProject(id),
        api.listDocuments(id),
        api.getProjectBOQ(id).catch(() => null),
        api.getCostSummary(id).catch(() => null),
      ]);
      setProject(p);
      setDocuments(docs);
      setBoq(boqSummary);
      setCostSummary(cost);
      setCostForm({
        overhead_percent: Number(p.overhead_percent),
        profit_percent: Number(p.profit_percent),
        contingency_percent: Number(p.contingency_percent),
        tax_percent: Number(p.tax_percent),
      });
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) router.push("/login");
      else setError("Could not load project");
    }
  }, [id, router]);

  useEffect(() => {
    load();
  }, [load]);

  // Poll any in-flight jobs every 1.5s until terminal state.
  useEffect(() => {
    const inFlight = Object.values(activeJobs).filter(
      (j) => !["DRAFT_OUTPUT", "COMPLETED", "FAILED"].includes(j.status)
    );
    if (inFlight.length === 0) return;
    const interval = setInterval(async () => {
      for (const job of inFlight) {
        const updated = await api.getJob(job.id);
        setActiveJobs((prev) => ({ ...prev, [job.id]: updated }));
        if (["DRAFT_OUTPUT", "COMPLETED"].includes(updated.status)) {
          const boqSummary = await api.getProjectBOQ(id).catch(() => null);
          setBoq(boqSummary);
          const cost = await api.getCostSummary(id).catch(() => null);
          setCostSummary(cost);
          const review = await api.getJobReview(updated.id).catch(() => []);
          setReviewQueue((prev) => {
            const existingIds = new Set(prev.map((e) => e.id));
            return [...prev, ...review.filter((e) => !existingIds.has(e.id))];
          });
        }
      }
    }, 1500);
    return () => clearInterval(interval);
  }, [activeJobs, id]);

  async function handleUpload(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fileInput = (e.target as HTMLFormElement).elements.namedItem("file") as HTMLInputElement;
    const file = fileInput.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);
    try {
      const doc = await api.uploadDocument(id, file, meta);
      setDocuments((prev) => [doc, ...prev]);
      fileInput.value = "";

      const job = await api.processDocument(doc.id, ["quantities", "boq"]);
      setActiveJobs((prev) => ({ ...prev, [job.id]: job }));
    } catch {
      setError("Upload or processing failed to start");
    } finally {
      setUploading(false);
    }
  }

  async function loadOverlay(jobId: string, page: number, docName: string) {
    setCheck((c) => ({
      docName, jobId, page, pageCount: c?.pageCount ?? 1, url: null,
      elements: c?.elements ?? [], loading: true, error: null,
    }));
    try {
      const [overlay, elements] = await Promise.all([
        api.getOverlay(jobId, page),
        api.getJobElements(jobId),
      ]);
      setCheck({
        docName, jobId, page, pageCount: overlay.pageCount, url: overlay.url,
        elements, loading: false, error: null,
      });
    } catch (err) {
      setCheck({
        docName, jobId, page, pageCount: 1, url: null, elements: [], loading: false,
        error: err instanceof ApiError ? err.message : "Could not load the drawing check",
      });
    }
  }

  async function openCheck(doc: Document) {
    try {
      const job = activeJobsByDoc[doc.id] ?? (await api.getLatestJob(doc.id));
      await loadOverlay(job.id, 1, doc.file_name);
    } catch {
      setCheck({
        docName: doc.file_name, jobId: "", page: 1, pageCount: 1, url: null, elements: [],
        loading: false, error: "This document has not been processed yet.",
      });
    }
  }

  async function handleSaveCostSettings(e: React.FormEvent) {
    e.preventDefault();
    setSavingCostSettings(true);
    try {
      await api.updateCostSettings(id, costForm);
      const cost = await api.getCostSummary(id);
      setCostSummary(cost);
    } catch {
      setError("Could not save cost settings");
    } finally {
      setSavingCostSettings(false);
    }
  }

  if (!project) {
    return (
      <div className="min-h-screen">
        <TopBar />
        <main className="mx-auto max-w-6xl px-6 py-10 text-muted">Loading…</main>
      </div>
    );
  }

  const jobsByDoc = activeJobsByDoc;

  return (
    <div className="min-h-screen">
      <TopBar crumb={project.name} />
      <main className="mx-auto max-w-6xl px-6 py-10">
        <div className="mb-10">
          <div className="mono-tag mb-2">
            {project.location || "NO LOCATION"} · {project.currency}
          </div>
          <h1 className="font-display text-3xl font-bold tracking-tight">{project.name}</h1>
        </div>

        {error && <p className="mb-4 text-sm text-danger">{error}</p>}

        <div className="grid gap-10 lg:grid-cols-5">
          {/* Documents + upload */}
          <section className="lg:col-span-2">
            <h2 className="mono-tag mb-3">DOCUMENT REGISTER</h2>

            <form
              onSubmit={handleUpload}
              className="ledger-row mb-6 space-y-3 rounded-r-md bg-surface p-5"
              data-ref="UPLOAD"
            >
              <input
                type="file"
                name="file"
                required
                className="w-full text-sm file:mr-3 file:rounded file:border-0 file:bg-blueprintDim file:px-3 file:py-1.5 file:text-blueprint file:text-xs"
              />
              <div className="grid grid-cols-2 gap-3">
                <select
                  value={meta.discipline}
                  onChange={(e) => setMeta({ ...meta, discipline: e.target.value })}
                  className="rounded border border-line bg-ink px-2 py-1.5 text-xs outline-none focus:border-blueprint"
                >
                  {["architectural", "structural", "mep", "civil"].map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
                <input
                  value={meta.document_number}
                  onChange={(e) => setMeta({ ...meta, document_number: e.target.value })}
                  placeholder="Drawing no."
                  className="rounded border border-line bg-ink px-2 py-1.5 text-xs outline-none focus:border-blueprint"
                />
              </div>
              <div>
                <label className="mono-tag mb-1 block">
                  PLOT SCALE (1 : <span className="text-blueprint">{meta.scale_ratio}</span>) — must
                  match the sheet
                </label>
                <input
                  type="number"
                  min={1}
                  value={meta.scale_ratio}
                  onChange={(e) => setMeta({ ...meta, scale_ratio: Number(e.target.value) })}
                  className="w-full rounded border border-line bg-ink px-2 py-1.5 text-xs outline-none focus:border-blueprint"
                />
                <p className="mt-1 text-xs text-muted">
                  Wrong scale = wrong quantities. Use the scale printed on the drawing sheet.
                </p>
              </div>
              <button
                type="submit"
                disabled={uploading}
                className="w-full rounded bg-blueprint py-2 text-xs font-medium text-ink hover:opacity-90 disabled:opacity-50"
              >
                {uploading ? "UPLOADING…" : "UPLOAD & PROCESS"}
              </button>
            </form>

            <div className="space-y-2">
              {documents.length === 0 && (
                <p className="text-sm text-muted">No documents registered yet.</p>
              )}
              {documents.map((d) => {
                const job = jobsByDoc[d.id];
                return (
                  <div
                    key={d.id}
                    className="ledger-row rounded-r-md bg-surface p-4"
                    data-ref={d.document_number || d.id.slice(0, 6)}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{d.file_name}</p>
                        <p className="mono-tag mt-1">
                          {d.discipline} · rev {d.revision}
                        </p>
                      </div>
                      <StatusPill status={job?.status || d.status} />
                    </div>
                    {job && job.progress > 0 && job.progress < 100 && (
                      <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-line">
                        <div
                          className="h-full bg-blueprint transition-all"
                          style={{ width: `${job.progress}%` }}
                        />
                      </div>
                    )}
                    {job?.warnings && (
                      <p className="mt-2 text-xs text-amber">{job.warnings}</p>
                    )}
                    {d.file_name.toLowerCase().endsWith(".pdf") && (
                      <button
                        type="button"
                        onClick={() => openCheck(d)}
                        className="mono-tag mt-3 rounded border border-line px-3 py-1.5 text-paper transition-colors hover:border-blueprint hover:text-blueprint"
                      >
                        CHECK ON DRAWING
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {/* BOQ */}
          <section className="lg:col-span-3">
            <div className="mb-3 flex items-baseline justify-between">
              <h2 className="mono-tag">BILL OF QUANTITIES</h2>
              {boq && (
                <span className="font-mono text-sm text-muted">
                  direct cost: {boq.currency} {Number(boq.total_amount).toLocaleString()}
                </span>
              )}
            </div>

            {(!boq || boq.lines.length === 0) && (
              <div className="ledger-row rounded-r-md bg-surface p-8" data-ref="BOQ">
                <p className="text-sm text-muted">
                  No BOQ lines yet. Upload a drawing to generate a preliminary take-off.
                </p>
              </div>
            )}

            {boq && boq.lines.length > 0 && (
              <div className="overflow-hidden rounded-md border border-line">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-line bg-surface text-left mono-tag">
                      <th className="px-4 py-2 font-normal">QTY</th>
                      <th className="px-4 py-2 font-normal">RATE</th>
                      <th className="px-4 py-2 font-normal">AMOUNT</th>
                      <th className="px-4 py-2 font-normal">STATUS</th>
                    </tr>
                  </thead>
                  <tbody className="font-mono">
                    {boq.lines.map((line) => (
                      <tr key={line.id} className="border-b border-line last:border-0">
                        <td className="px-4 py-2">{Number(line.quantity).toLocaleString()}</td>
                        <td className="px-4 py-2 text-muted">
                          {Number(line.rate).toLocaleString()}
                        </td>
                        <td className="px-4 py-2 text-blueprint">
                          {Number(line.amount).toLocaleString()}
                        </td>
                        <td className="px-4 py-2">
                          <StatusPill status={line.status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {boq && boq.lines.length > 0 && (
              <div className="ledger-row mt-8 rounded-r-md bg-surface p-5" data-ref="FINAL">
                <h2 className="mono-tag mb-4">FINAL ESTIMATE</h2>

                <form
                  onSubmit={handleSaveCostSettings}
                  className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4"
                >
                  {(
                    [
                      ["overhead_percent", "OVERHEAD %"],
                      ["profit_percent", "PROFIT %"],
                      ["contingency_percent", "CONTINGENCY %"],
                      ["tax_percent", "TAX %"],
                    ] as const
                  ).map(([key, label]) => (
                    <div key={key}>
                      <label className="mono-tag mb-1 block">{label}</label>
                      <input
                        type="number"
                        min={0}
                        step="0.1"
                        value={costForm[key]}
                        onChange={(e) =>
                          setCostForm({ ...costForm, [key]: Number(e.target.value) })
                        }
                        className="w-full rounded border border-line bg-ink px-2 py-1.5 text-sm outline-none focus:border-blueprint"
                      />
                    </div>
                  ))}
                  <button
                    type="submit"
                    disabled={savingCostSettings}
                    className="col-span-2 rounded bg-blueprintDim py-2 text-xs font-medium text-blueprint hover:opacity-90 disabled:opacity-50 sm:col-span-4"
                  >
                    {savingCostSettings ? "SAVING…" : "APPLY MARKUPS"}
                  </button>
                </form>

                {costSummary && (
                  <div className="space-y-1.5 border-t border-line pt-4 font-mono text-sm">
                    <Row label="Direct cost (BOQ)" value={costSummary.direct_cost} />
                    <Row
                      label={`+ Overhead (${costSummary.overhead_percent}%)`}
                      value={costSummary.overhead_amount}
                      muted
                    />
                    <Row label="Subtotal" value={costSummary.subtotal_after_overhead} />
                    <Row
                      label={`+ Profit (${costSummary.profit_percent}%)`}
                      value={costSummary.profit_amount}
                      muted
                    />
                    <Row label="Subtotal" value={costSummary.subtotal_after_profit} />
                    <Row
                      label={`+ Contingency (${costSummary.contingency_percent}%)`}
                      value={costSummary.contingency_amount}
                      muted
                    />
                    <Row label="Subtotal" value={costSummary.subtotal_after_contingency} />
                    <Row
                      label={`+ Tax (${costSummary.tax_percent}%)`}
                      value={costSummary.tax_amount}
                      muted
                    />
                    <div className="mt-3 flex items-center justify-between border-t border-line pt-3">
                      <span className="font-display text-base font-bold text-paper">
                        GRAND TOTAL
                      </span>
                      <span className="font-display text-xl font-bold text-blueprint">
                        {costSummary.currency} {Number(costSummary.grand_total).toLocaleString()}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {reviewQueue.length > 0 && (
              <div className="mt-8">
                <div className="mb-3 flex items-center gap-2">
                  <h2 className="mono-tag">NEEDS REVIEW</h2>
                  <span className="rounded-full border border-amber/40 bg-amber/10 px-2 py-0.5 text-xs font-mono text-amber">
                    {reviewQueue.length}
                  </span>
                </div>
                <p className="mb-3 text-xs text-muted">
                  Held back from the BOQ automatically — confidence below 80%. Confirm the class
                  and quantity, then price manually or re-map the catalogue code.
                </p>
                <div className="space-y-2">
                  {reviewQueue.map((el) => (
                    <div
                      key={el.id}
                      className="ledger-row rounded-r-md bg-surface p-3 text-sm"
                      data-ref={el.matched_label || "?"}
                    >
                      <div className="flex items-center justify-between">
                        <span>
                          <span className="font-medium capitalize">{el.element_class}</span>
                          <span className="mono-tag ml-2">
                            {Number(el.value).toLocaleString()} {el.unit}
                          </span>
                        </span>
                        <span className="mono-tag text-amber">
                          {Math.round(Number(el.confidence) * 100)}% confidence
                        </span>
                      </div>
                      <p className="mono-tag mt-1 text-muted">{el.source_reference}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>
        </div>

        {check && (
          <section className="mt-12" id="check">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="mono-tag">CHECK ON DRAWING — {check.docName}</h2>
                <p className="mt-1 text-xs text-muted">
                  Every detected element is boxed and numbered on the sheet. Compare each number
                  with the table: <span className="text-ok">green</span> = 80%+,{" "}
                  <span className="text-amber">amber</span> = 50–80%,{" "}
                  <span className="text-danger">red</span> = under 50% (not priced).
                </p>
              </div>
              <div className="flex items-center gap-2">
                {check.pageCount > 1 && (
                  <>
                    <button
                      disabled={check.page <= 1 || check.loading}
                      onClick={() => loadOverlay(check.jobId, check.page - 1, check.docName)}
                      className="mono-tag rounded border border-line px-3 py-1.5 disabled:opacity-40"
                    >
                      PREV
                    </button>
                    <span className="mono-tag">
                      PAGE {check.page} / {check.pageCount}
                    </span>
                    <button
                      disabled={check.page >= check.pageCount || check.loading}
                      onClick={() => loadOverlay(check.jobId, check.page + 1, check.docName)}
                      className="mono-tag rounded border border-line px-3 py-1.5 disabled:opacity-40"
                    >
                      NEXT
                    </button>
                  </>
                )}
                <button
                  onClick={() => setCheck(null)}
                  className="mono-tag rounded border border-line px-3 py-1.5 hover:border-danger hover:text-danger"
                >
                  CLOSE
                </button>
              </div>
            </div>

            {check.loading && <p className="text-sm text-muted">Rendering drawing…</p>}
            {check.error && <p className="text-sm text-danger">{check.error}</p>}

            {check.url && (
              <div className="grid gap-6 lg:grid-cols-5">
                <div className="overflow-auto rounded-md border border-line bg-white lg:col-span-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={check.url} alt="Drawing with detected elements" className="w-full" />
                </div>
                <div className="max-h-[70vh] overflow-auto rounded-md border border-line lg:col-span-2">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="sticky top-0 border-b border-line bg-surface text-left mono-tag">
                        <th className="px-3 py-2 font-normal">#</th>
                        <th className="px-3 py-2 font-normal">CLASS</th>
                        <th className="px-3 py-2 font-normal">QTY</th>
                        <th className="px-3 py-2 font-normal">CONF</th>
                      </tr>
                    </thead>
                    <tbody className="font-mono">
                      {check.elements.map((el, i) => {
                        const conf = Number(el.confidence);
                        const tone =
                          conf >= 0.8 ? "text-ok" : conf >= 0.5 ? "text-amber" : "text-danger";
                        return (
                          <tr
                            key={el.id}
                            className={`border-b border-line last:border-0 ${
                              el.page_number !== check.page ? "opacity-40" : ""
                            }`}
                          >
                            <td className="px-3 py-2 text-muted">{i + 1}</td>
                            <td className="px-3 py-2 capitalize">
                              {el.element_class}
                              {el.matched_label && (
                                <span className="mono-tag ml-2">{el.matched_label}</span>
                              )}
                            </td>
                            <td className="px-3 py-2">
                              {Number(el.value).toLocaleString()} {el.unit}
                            </td>
                            <td className={`px-3 py-2 ${tone}`}>{Math.round(conf * 100)}%</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </section>
        )}
      </main>
    </div>
  );
}
