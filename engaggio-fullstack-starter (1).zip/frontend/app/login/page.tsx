"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api, setToken, ApiError } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const { access_token } = await api.login(email, password);
      setToken(access_token);
      router.push("/dashboard");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Sign in failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-6xl flex-col justify-center px-6">
      <div className="mb-12">
        <div className="mono-tag mb-3">TENANT SIGN-IN</div>
        <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
          ENGAGGIO
        </h1>
        <p className="mt-3 font-mono text-sm text-muted">
          DRAWINGS <span className="text-blueprint">→</span> QUANTITIES{" "}
          <span className="text-blueprint">→</span> BOQ{" "}
          <span className="text-blueprint">→</span> BBS{" "}
          <span className="text-blueprint">→</span> COST{" "}
          <span className="text-blueprint">→</span> TIMELINE
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="ledger-row max-w-sm space-y-4 rounded-r-md bg-surface p-6"
        data-ref="LOGIN"
      >
        <div>
          <label className="mono-tag mb-1 block">EMAIL</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded border border-line bg-ink px-3 py-2 text-sm outline-none focus:border-blueprint"
            placeholder="admin@yourcompany.com"
          />
        </div>
        <div>
          <label className="mono-tag mb-1 block">PASSWORD</label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded border border-line bg-ink px-3 py-2 text-sm outline-none focus:border-blueprint"
            placeholder="••••••••"
          />
        </div>
        {error && <p className="text-sm text-danger">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded bg-blueprint py-2 text-sm font-medium text-ink transition-opacity hover:opacity-90 disabled:opacity-50"
        >
          {loading ? "SIGNING IN…" : "SIGN IN"}
        </button>
        <p className="text-sm text-muted">
          New tenant?{" "}
          <Link href="/signup" className="text-blueprint hover:underline">
            Provision one
          </Link>
        </p>
      </form>
    </main>
  );
}
