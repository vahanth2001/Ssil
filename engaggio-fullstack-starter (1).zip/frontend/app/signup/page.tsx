"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api, setToken, ApiError } from "@/lib/api";

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    tenant_name: "",
    admin_full_name: "",
    admin_email: "",
    password: "",
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const { access_token } = await api.signup(form);
      setToken(access_token);
      router.push("/dashboard");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not provision tenant");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-6xl flex-col justify-center px-6">
      <div className="mb-10">
        <div className="mono-tag mb-3">NEW TENANT</div>
        <h1 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Provision your workspace
        </h1>
      </div>

      <form
        onSubmit={handleSubmit}
        className="ledger-row max-w-sm space-y-4 rounded-r-md bg-surface p-6"
        data-ref="SIGNUP"
      >
        {[
          { key: "tenant_name", label: "COMPANY / TENANT NAME", type: "text", placeholder: "Sri Sarveshwara Infra & Logistics" },
          { key: "admin_full_name", label: "YOUR NAME", type: "text", placeholder: "Full name" },
          { key: "admin_email", label: "EMAIL", type: "email", placeholder: "you@company.com" },
          { key: "password", label: "PASSWORD", type: "password", placeholder: "••••••••" },
        ].map((f) => (
          <div key={f.key}>
            <label className="mono-tag mb-1 block">{f.label}</label>
            <input
              type={f.type}
              required
              value={(form as any)[f.key]}
              onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
              className="w-full rounded border border-line bg-ink px-3 py-2 text-sm outline-none focus:border-blueprint"
              placeholder={f.placeholder}
            />
          </div>
        ))}
        {error && <p className="text-sm text-danger">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded bg-blueprint py-2 text-sm font-medium text-ink transition-opacity hover:opacity-90 disabled:opacity-50"
        >
          {loading ? "PROVISIONING…" : "CREATE TENANT"}
        </button>
        <p className="text-sm text-muted">
          Already have a tenant?{" "}
          <Link href="/login" className="text-blueprint hover:underline">
            Sign in
          </Link>
        </p>
      </form>
    </main>
  );
}
