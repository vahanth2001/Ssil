"""Synthetic 'real-world-like' sheet: the clean floor plan from test_generate_pdf.py
PLUS the clutter real CAD exports contain, to prove the noise filters work.
Expected survivors: the same 13 genuine elements; everything else is ignored."""
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, black

c = canvas.Canvas("/tmp/noisy_floorplan.pdf", pagesize=(600, 400))

# --- noise: sheet border + title block + inner frame
c.setStrokeColor(black); c.setLineWidth(1)
c.rect(1, 1, 598, 398, fill=0, stroke=1)          # sheet border (>95% of page)
c.rect(3, 3, 594, 394, fill=0, stroke=1)          # double border
c.rect(450, 5, 140, 40, fill=0, stroke=1)         # title block
c.drawString(455, 30, "TITLE BLOCK")

# --- noise: grid lines + dimension lines (long hairlines)
c.setLineWidth(0.4)
for x in (60, 300, 540):
    c.line(x, 5, x, 395)
for y in (60, 200, 340):
    c.line(5, y, 595, y)
c.line(20, 392, 580, 392)                          # dimension line

# --- noise: hatching ticks and arrowheads (tiny shapes)
for i in range(60):
    c.rect(100 + (i % 20) * 6, 300 + (i // 20) * 6, 1.5, 1.5, fill=1, stroke=0)

# --- genuine elements (same as clean fixture)
c.setLineWidth(1)
c.setFillColor(HexColor("#dddddd")); c.rect(20, 20, 560, 360, fill=1, stroke=1)
c.setFillColor(black); c.drawString(280, 260, "SLAB")
c.setFillColor(HexColor("#333333"))
c.rect(20, 370, 560, 10, fill=1, stroke=0); c.drawString(290, 372, "WALL")
c.rect(20, 20, 10, 360, fill=1, stroke=0);  c.drawString(5, 200, "WALL")
c.rect(570, 20, 10, 360, fill=1, stroke=0); c.drawString(575, 200, "WALL")
c.rect(20, 20, 560, 10, fill=1, stroke=0);  c.drawString(290, 5, "WL-01")
for i, (x, y) in enumerate([(60, 60), (540, 60), (60, 340), (540, 340), (300, 200)], 1):
    c.setFillColor(HexColor("#555555")); c.rect(x, y, 12, 12, fill=1, stroke=0)
    c.setFillColor(black); c.drawString(x - 2, y + 14, f"C{i}")
c.setFillColor(HexColor("#777777")); c.rect(60, 190, 480, 8, fill=1, stroke=0); c.drawString(280, 178, "BEAM")
c.setFillColor(HexColor("#999999")); c.rect(250, 60, 22, 22, fill=1, stroke=0); c.drawString(245, 50, "F1")
c.setFillColor(HexColor("#bbbbbb")); c.rect(150, 280, 18, 15, fill=1, stroke=0)  # unlabeled

# --- noise: the beam and a column drawn twice (double-stroked outline)
c.setFillColor(HexColor("#777777")); c.rect(60, 190, 480, 8, fill=1, stroke=0)
c.setFillColor(HexColor("#555555")); c.rect(60, 60, 12, 12, fill=1, stroke=0)
c.showPage(); c.save()
print("Generated /tmp/noisy_floorplan.pdf")
