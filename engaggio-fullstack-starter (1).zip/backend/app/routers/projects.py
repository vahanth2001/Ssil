from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user
from ..database import get_db

router = APIRouter(prefix="/api/v1/projects", tags=["projects"])


@router.post("", response_model=schemas.ProjectOut)
def create_project(
    payload: schemas.ProjectCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    project = models.Project(tenant_id=current_user.tenant_id, **payload.model_dump())
    db.add(project)
    db.flush()
    db.add(models.AuditEvent(
        tenant_id=current_user.tenant_id, actor_email=current_user.email,
        action="project.created", object_type="Project", object_id=project.id,
    ))
    db.commit()
    db.refresh(project)
    return project


@router.get("", response_model=list[schemas.ProjectOut])
def list_projects(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    return (
        db.query(models.Project)
        .filter(models.Project.tenant_id == current_user.tenant_id)
        .order_by(models.Project.created_at.desc())
        .all()
    )


@router.get("/{project_id}", response_model=schemas.ProjectOut)
def get_project(
    project_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    project = _get_owned_project(db, project_id, current_user)
    return project


def _get_owned_project(db: Session, project_id: str, current_user: models.User) -> models.Project:
    """Strict tenant isolation: a project must belong to the caller's tenant (section 14)."""
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project or project.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="Project not found")
    return project
