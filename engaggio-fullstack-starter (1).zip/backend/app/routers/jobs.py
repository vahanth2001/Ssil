import pymupdf
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Response
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user
from ..database import SessionLocal, get_db
from ..services.boq_engine import generate_boq_lines
from ..services.extraction import run_extraction

router = APIRouter(prefix="/api/v1", tags=["jobs"])


@router.post("/documents/{document_id}/process", response_model=schemas.JobOut)
def process_document(
    document_id: str,
    payload: schemas.ProcessRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Mirrors the example API contract in spec section 13: enqueue a job,
    return immediately with status QUEUED, and process asynchronously
    (state machine in section 8)."""
    document = db.query(models.Document).filter(models.Document.id == document_id).first()
    if not document or document.project.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="Document not found")

    job = models.Job(document_id=document.id, outputs=",".join(payload.outputs))
    db.add(job)
    db.commit()
    db.refresh(job)

    background_tasks.add_task(_run_pipeline, job.id, document.project_id, current_user.tenant_id)
    return job


def _run_pipeline(job_id: str, project_id: str, tenant_id: str):
    """Simulated background worker walking the state machine in section 8.
    Runs in its own DB session, as a real Celery/RQ worker would."""
    db = SessionLocal()
    try:
        job = db.query(models.Job).filter(models.Job.id == job_id).first()
        if not job:
            return

        job.status = models.JobStatus.EXTRACTING
        job.progress = 20
        db.commit()

        document = db.query(models.Document).filter(models.Document.id == job.document_id).first()
        elements = run_extraction(db, job, document)

        job.status = models.JobStatus.CLASSIFYING
        job.progress = 50
        db.commit()

        low_confidence = [e for e in elements if float(e.confidence) < 0.8]
        if low_confidence:
            note = f"{len(low_confidence)} element(s) below confidence threshold, routed for review"
            job.warnings = f"{job.warnings} {note}" if job.warnings else note

        job.status = models.JobStatus.CALCULATING
        job.progress = 70
        db.commit()

        if "boq" in job.outputs:
            generate_boq_lines(db, project_id, tenant_id, elements)

        job.status = models.JobStatus.DRAFT_OUTPUT
        job.progress = 100
        db.commit()
    except Exception as exc:  # pragma: no cover - defensive worker guard
        db.rollback()
        job = db.query(models.Job).filter(models.Job.id == job_id).first()
        if job:
            job.status = models.JobStatus.FAILED
            job.errors = str(exc)
            db.commit()
    finally:
        db.close()


@router.get("/jobs/{job_id}", response_model=schemas.JobOut)
def get_job(
    job_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not job or job.document.project.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.get("/jobs/{job_id}/elements", response_model=list[schemas.ElementOut])
def get_job_elements(
    job_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not job or job.document.project.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="Job not found")
    return _ordered_elements(db, job.id)


def _ordered_elements(db: Session, job_id: str) -> list[models.Element]:
    """Single source of truth for element numbering: the list endpoint and the
    overlay image must agree so '#7' on the drawing is item 7 in the list."""
    return (
        db.query(models.Element)
        .filter(models.Element.job_id == job_id)
        .order_by(models.Element.created_at, models.Element.id)
        .all()
    )


@router.get("/jobs/{job_id}/overlay")
def job_overlay(
    job_id: str,
    page: int = Query(1, ge=1),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Renders the uploaded drawing with every detected element boxed and
    numbered, colour-coded by confidence (green >= 80%, amber 50-80%, red
    below 50%), so a reviewer can check each detection against the sheet."""
    job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not job or job.document.project.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="Job not found")
    path = job.document.file_path
    if not path.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Overlay is only available for PDF drawings")

    pdf = pymupdf.open(path)
    try:
        if page > len(pdf):
            raise HTTPException(status_code=404, detail=f"Page {page} does not exist")
        pg = pdf[page - 1]
        for number, el in enumerate(_ordered_elements(db, job.id), start=1):
            if el.page_number != page or el.bbox_x0 is None:
                continue
            conf = float(el.confidence)
            color = (0.15, 0.65, 0.35) if conf >= 0.8 else (0.85, 0.55, 0.1) if conf >= 0.5 else (0.8, 0.2, 0.2)
            rect = pymupdf.Rect(el.bbox_x0, el.bbox_y0, el.bbox_x1, el.bbox_y1)
            pg.draw_rect(rect, color=color, width=1.2)
            pg.insert_text(
                (rect.x0, max(rect.y0 - 2, 8)), f"#{number} {el.element_class}",
                fontsize=7, color=color,
            )
        png = pg.get_pixmap(matrix=pymupdf.Matrix(2, 2)).tobytes("png")
        return Response(content=png, media_type="image/png", headers={"X-Page-Count": str(len(pdf))})
    finally:
        pdf.close()


@router.get("/documents/{document_id}/jobs/latest", response_model=schemas.JobOut)
def latest_job_for_document(
    document_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    document = db.query(models.Document).filter(models.Document.id == document_id).first()
    if not document or document.project.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="Document not found")
    job = (
        db.query(models.Job)
        .filter(models.Job.document_id == document.id)
        .order_by(models.Job.created_at.desc())
        .first()
    )
    if not job:
        raise HTTPException(status_code=404, detail="No processing job for this document yet")
    return job
