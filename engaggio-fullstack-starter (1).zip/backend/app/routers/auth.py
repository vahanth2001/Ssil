from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import create_access_token, get_current_user, hash_password, verify_password
from ..database import get_db

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


@router.post("/signup", response_model=schemas.TokenResponse)
def signup(payload: schemas.TenantSignup, db: Session = Depends(get_db)):
    """Provisions a new tenant with its first Tenant Administrator (section 6.1)."""
    if db.query(models.User).filter(models.User.email == payload.admin_email).first():
        raise HTTPException(status_code=409, detail="Email already registered")

    tenant = models.Tenant(name=payload.tenant_name)
    db.add(tenant)
    db.flush()

    user = models.User(
        tenant_id=tenant.id,
        email=payload.admin_email,
        full_name=payload.admin_full_name,
        hashed_password=hash_password(payload.password),
        role=models.RoleEnum.TENANT_ADMIN,
    )
    db.add(user)
    db.add(models.AuditEvent(
        tenant_id=tenant.id, actor_email=user.email, action="tenant.provisioned",
        object_type="Tenant", object_id=tenant.id,
    ))
    db.commit()

    token = create_access_token(subject=user.email, tenant_id=tenant.id)
    return schemas.TokenResponse(access_token=token)


@router.post("/login", response_model=schemas.TokenResponse)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    token = create_access_token(subject=user.email, tenant_id=user.tenant_id)
    return schemas.TokenResponse(access_token=token)


@router.get("/me", response_model=schemas.UserOut)
def me(current_user: models.User = Depends(get_current_user)):
    return current_user
