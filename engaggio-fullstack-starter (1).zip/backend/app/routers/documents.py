import hashlib
import shutil
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user
from ..config import settings
from ..database import get_db
from .projects import _get_owned_project

router = APIRouter(prefix="/api/v1", tags=["documents"])


@router.post("/projects/{project_id}/documents", response_model=schemas.DocumentOut)
def upload_document(
    project_id: str,
    file: UploadFile = File(...),
    discipline: str = Form("architectural"),
    document_number: str = Form(""),
    revision: str = Form("A"),
    scale_ratio: int = Form(100),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Mirrors the example API contract in spec section 13."""
    project = _get_owned_project(db, project_id, current_user)

    dest_dir = settings.STORAGE_ROOT / project.tenant_id / project.id
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_path = dest_dir / file.filename

    hasher = hashlib.sha256()
    with open(dest_path, "wb") as out:
        while chunk := file.file.read(1024 * 1024):
            hasher.update(chunk)
            out.write(chunk)

    document = models.Document(
        project_id=project.id,
        file_name=file.filename,
        file_path=str(dest_path),
        checksum=hasher.hexdigest(),
        discipline=discipline,
        document_number=document_number or None,
        revision=revision,
        scale_ratio=scale_ratio,
        status=models.DocumentStatus.REGISTERED,
    )
    db.add(document)
    db.flush()
    db.add(models.AuditEvent(
        tenant_id=current_user.tenant_id, actor_email=current_user.email,
        action="document.uploaded", object_type="Document", object_id=document.id,
        detail=f"checksum={document.checksum}",
    ))
    db.commit()
    db.refresh(document)
    return document


@router.get("/projects/{project_id}/documents", response_model=list[schemas.DocumentOut])
def list_documents(
    project_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    project = _get_owned_project(db, project_id, current_user)
    return (
        db.query(models.Document)
        .filter(models.Document.project_id == project.id)
        .order_by(models.Document.uploaded_at.desc())
        .all()
    )
