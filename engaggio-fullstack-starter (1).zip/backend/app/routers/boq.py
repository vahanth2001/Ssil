from decimal import Decimal

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user
from ..database import get_db
from ..services.cost_summary import compute_cost_summary
from .projects import _get_owned_project

router = APIRouter(prefix="/api/v1", tags=["boq"])


@router.post("/catalogue-items", response_model=schemas.CatalogueItemOut)
def create_catalogue_item(
    payload: schemas.CatalogueItemCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Tenant-scoped rate library entry (spec section 6.7)."""
    item = models.BOQCatalogueItem(tenant_id=current_user.tenant_id, **payload.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@router.get("/catalogue-items", response_model=list[schemas.CatalogueItemOut])
def list_catalogue_items(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    return (
        db.query(models.BOQCatalogueItem)
        .filter(models.BOQCatalogueItem.tenant_id == current_user.tenant_id)
        .all()
    )


@router.get("/projects/{project_id}/boq", response_model=schemas.BOQSummaryOut)
def get_project_boq(
    project_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    project = _get_owned_project(db, project_id, current_user)
    lines = (
        db.query(models.BOQLine)
        .filter(models.BOQLine.project_id == project.id)
        .order_by(models.BOQLine.created_at.desc())
        .all()
    )
    total = sum((line.amount for line in lines), Decimal("0.00"))
    return schemas.BOQSummaryOut(
        project_id=project.id,
        currency=project.currency,
        line_count=len(lines),
        total_amount=total,
        lines=lines,
    )


@router.put("/projects/{project_id}/cost-settings", response_model=schemas.ProjectOut)
def update_cost_settings(
    project_id: str,
    payload: schemas.CostSettingsUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Sets the overhead/profit/contingency/tax percentages used to compute
    the final quoted estimate (spec section 6.7)."""
    project = _get_owned_project(db, project_id, current_user)
    project.overhead_percent = payload.overhead_percent
    project.profit_percent = payload.profit_percent
    project.contingency_percent = payload.contingency_percent
    project.tax_percent = payload.tax_percent
    db.add(models.AuditEvent(
        tenant_id=current_user.tenant_id, actor_email=current_user.email,
        action="project.cost_settings_updated", object_type="Project", object_id=project.id,
        detail=str(payload.model_dump()),
    ))
    db.commit()
    db.refresh(project)
    return project


@router.get("/projects/{project_id}/cost-summary", response_model=schemas.CostSummaryOut)
def get_cost_summary(
    project_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """The final quoted estimate: raw BOQ sum with overhead, profit,
    contingency, and tax applied in sequence (spec section 6.7). This is
    the number that answers 'what is the final amount' — the BOQ total
    alone is only the direct cost."""
    project = _get_owned_project(db, project_id, current_user)
    lines = db.query(models.BOQLine).filter(models.BOQLine.project_id == project.id).all()
    direct_cost = sum((line.amount for line in lines), Decimal("0.00"))
    summary = compute_cost_summary(project, direct_cost)
    return schemas.CostSummaryOut(**summary)
