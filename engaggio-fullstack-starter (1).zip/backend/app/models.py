"""
Minimal slice of the canonical data model in the technical spec (section 9).
Full entity set (Sheet, Classification Evidence, Rebar Item, Activity,
Revision Comparison, etc.) is deferred — this covers the walking skeleton:
Tenant -> Project -> Document -> Job -> Element -> QuantityRecord -> BOQLine.
"""
import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    Column, String, DateTime, ForeignKey, Enum, Numeric, Text, Boolean, Integer, Float,
)
from sqlalchemy.orm import relationship

from .database import Base


def new_id() -> str:
    return str(uuid.uuid4())


class RoleEnum(str, enum.Enum):
    PLATFORM_SUPER_ADMIN = "platform_super_admin"
    TENANT_ADMIN = "tenant_admin"
    PROJECT_ADMIN = "project_admin"
    CAD_BIM_COORDINATOR = "cad_bim_coordinator"
    QUANTITY_SURVEYOR = "quantity_surveyor"
    STRUCTURAL_ENGINEER = "structural_engineer"
    PLANNER = "planner"
    ESTIMATOR = "estimator"
    REVIEWER = "reviewer"
    CLIENT_READ_ONLY = "client_read_only"


class DocumentStatus(str, enum.Enum):
    UPLOADED = "UPLOADED"
    SCANNED = "SCANNED"
    REGISTERED = "REGISTERED"
    PREFLIGHT_RUNNING = "PREFLIGHT_RUNNING"
    PREFLIGHT_FAILED = "PREFLIGHT_FAILED"
    READY = "READY"
    SUPERSEDED = "SUPERSEDED"


class JobStatus(str, enum.Enum):
    QUEUED = "QUEUED"
    EXTRACTING = "EXTRACTING"
    CLASSIFYING = "CLASSIFYING"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    CALCULATING = "CALCULATING"
    VALIDATING = "VALIDATING"
    DRAFT_OUTPUT = "DRAFT_OUTPUT"
    FAILED = "FAILED"
    COMPLETED = "COMPLETED"


class OutputStatus(str, enum.Enum):
    DRAFT = "Draft"
    REVIEW_REQUIRED = "Review Required"
    PRELIMINARY = "Preliminary"
    VALIDATED = "Validated"
    APPROVED = "Approved"
    PUBLISHED = "Published"
    SUPERSEDED = "Superseded"


class Tenant(Base):
    __tablename__ = "tenants"
    id = Column(String, primary_key=True, default=new_id)
    name = Column(String, nullable=False)
    region = Column(String, default="global")
    plan = Column(String, default="pilot")
    created_at = Column(DateTime, default=datetime.utcnow)

    users = relationship("User", back_populates="tenant", cascade="all, delete-orphan")
    projects = relationship("Project", back_populates="tenant", cascade="all, delete-orphan")


class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=new_id)
    tenant_id = Column(String, ForeignKey("tenants.id"), nullable=False)
    email = Column(String, unique=True, nullable=False, index=True)
    full_name = Column(String, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(Enum(RoleEnum), default=RoleEnum.QUANTITY_SURVEYOR)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    tenant = relationship("Tenant", back_populates="users")


class Project(Base):
    __tablename__ = "projects"
    id = Column(String, primary_key=True, default=new_id)
    tenant_id = Column(String, ForeignKey("tenants.id"), nullable=False)
    name = Column(String, nullable=False)
    location = Column(String)
    project_type = Column(String, default="general")
    units = Column(String, default="metric")
    currency = Column(String, default="USD")
    status = Column(String, default="active")
    # Cost markup settings (spec section 6.7: "Currency, tax, overhead,
    # profit, escalation and contingency settings"). Applied in sequence
    # on top of the raw BOQ sum to produce the final quoted estimate —
    # see services/cost_summary.py for the cascade.
    overhead_percent = Column(Numeric(5, 2), default=0)
    profit_percent = Column(Numeric(5, 2), default=0)
    contingency_percent = Column(Numeric(5, 2), default=0)
    tax_percent = Column(Numeric(5, 2), default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    tenant = relationship("Tenant", back_populates="projects")
    documents = relationship("Document", back_populates="project", cascade="all, delete-orphan")
    boq_lines = relationship("BOQLine", back_populates="project", cascade="all, delete-orphan")


class Document(Base):
    __tablename__ = "documents"
    id = Column(String, primary_key=True, default=new_id)
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    file_name = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    checksum = Column(String)
    discipline = Column(String, default="architectural")
    document_number = Column(String)
    revision = Column(String, default="A")
    # Plot scale denominator (e.g. 100 for a drawing plotted at 1:100).
    # Required for accurate real-world unit conversion when parsing vector
    # PDFs — see services/extraction_pdf.py.
    scale_ratio = Column(Integer, default=100)
    status = Column(Enum(DocumentStatus), default=DocumentStatus.UPLOADED)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="documents")
    jobs = relationship("Job", back_populates="document", cascade="all, delete-orphan")


class Job(Base):
    """Represents an asynchronous processing job (spec section 8, state machine)."""
    __tablename__ = "jobs"
    id = Column(String, primary_key=True, default=new_id)
    document_id = Column(String, ForeignKey("documents.id"), nullable=False)
    outputs = Column(String, default="quantities,boq")  # comma-separated
    status = Column(Enum(JobStatus), default=JobStatus.QUEUED)
    progress = Column(Integer, default=0)
    correlation_id = Column(String, default=new_id)
    warnings = Column(Text, default="")
    errors = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    document = relationship("Document", back_populates="jobs")
    elements = relationship("Element", back_populates="job", cascade="all, delete-orphan")


class Element(Base):
    """Extracted / classified construction element (spec section 6.5, 6.6)."""
    __tablename__ = "elements"
    id = Column(String, primary_key=True, default=new_id)
    job_id = Column(String, ForeignKey("jobs.id"), nullable=False)
    element_class = Column(String, nullable=False)  # e.g. "wall", "column", "slab"
    quantity_type = Column(String, nullable=False)  # length | area | volume | count | weight
    value = Column(Numeric(18, 4), nullable=False)
    unit = Column(String, nullable=False)
    confidence = Column(Numeric(5, 4), default=1.0)
    source_reference = Column(String, default="")  # sheet / layer / object trace
    matched_label = Column(String, nullable=True)  # nearby PDF text that drove classification
    # Location on the sheet (PDF points) so the element can be drawn back onto
    # the drawing for manual checking.
    page_number = Column(Integer, nullable=True)
    bbox_x0 = Column(Float, nullable=True)
    bbox_y0 = Column(Float, nullable=True)
    bbox_x1 = Column(Float, nullable=True)
    bbox_y1 = Column(Float, nullable=True)
    page_width = Column(Float, nullable=True)
    page_height = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    job = relationship("Job", back_populates="elements")


class BOQCatalogueItem(Base):
    """Rate catalogue entry, tenant-scoped (spec section 6.7)."""
    __tablename__ = "boq_catalogue_items"
    id = Column(String, primary_key=True, default=new_id)
    tenant_id = Column(String, ForeignKey("tenants.id"), nullable=False)
    code = Column(String, nullable=False)
    description = Column(String, nullable=False)
    unit = Column(String, nullable=False)
    trade = Column(String, default="general")
    rate = Column(Numeric(18, 2), nullable=False)
    currency = Column(String, default="USD")


class BOQLine(Base):
    """Generated BOQ line: quantity x rate = amount (spec section 6.7)."""
    __tablename__ = "boq_lines"
    id = Column(String, primary_key=True, default=new_id)
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    catalogue_item_id = Column(String, ForeignKey("boq_catalogue_items.id"), nullable=False)
    element_id = Column(String, ForeignKey("elements.id"), nullable=True)
    quantity = Column(Numeric(18, 4), nullable=False)
    rate = Column(Numeric(18, 2), nullable=False)
    amount = Column(Numeric(18, 2), nullable=False)
    status = Column(Enum(OutputStatus), default=OutputStatus.DRAFT)
    created_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="boq_lines")
    catalogue_item = relationship("BOQCatalogueItem")


class AuditEvent(Base):
    """Immutable audit trail (spec section 14, security & audit)."""
    __tablename__ = "audit_events"
    id = Column(String, primary_key=True, default=new_id)
    tenant_id = Column(String, ForeignKey("tenants.id"), nullable=True)
    actor_email = Column(String, nullable=False)
    action = Column(String, nullable=False)
    object_type = Column(String, nullable=False)
    object_id = Column(String, nullable=False)
    detail = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
