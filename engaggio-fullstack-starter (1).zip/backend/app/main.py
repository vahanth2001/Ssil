from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from . import models
from .config import settings
from .database import Base, engine
from .routers import auth, boq, documents, jobs, projects

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.APP_NAME,
    version="0.1.0",
    description=(
        "Minimal, real starter implementation of the Engaggio AI Construction "
        "Platform API — tenant/project/document lifecycle, a stubbed extraction "
        "pipeline, and a deterministic BOQ & cost engine. See the technical "
        "specification for the full target architecture."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Page-Count"],
)

app.include_router(auth.router)
app.include_router(projects.router)
app.include_router(documents.router)
app.include_router(jobs.router)
app.include_router(boq.router)


@app.get("/api/v1/health")
def health():
    return {"status": "ok", "service": settings.APP_NAME}
