"""
Central configuration. Values are read from environment variables so the
same image can be promoted across dev / UAT / production without rebuilds
(see spec section 19, Delivery Environments and DevOps).
"""
import os
from pathlib import Path


class Settings:
    APP_NAME: str = "Engaggio AI Construction Platform"

    # Storage of original + derivative files (object storage in production,
    # local disk for this starter — see spec section 5, "Object Storage").
    STORAGE_ROOT: Path = Path(os.getenv("STORAGE_ROOT", "./storage"))

    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./engaggio.db")

    JWT_SECRET: str = os.getenv("JWT_SECRET", "dev-secret-change-me")
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = int(os.getenv("JWT_EXPIRE_MINUTES", "480"))

    # CORS for the Next.js frontend during local development.
    CORS_ORIGINS: list[str] = os.getenv(
        "CORS_ORIGINS", "http://localhost:3000"
    ).split(",")


settings = Settings()
settings.STORAGE_ROOT.mkdir(parents=True, exist_ok=True)
