"""
Real vector-PDF extraction & classification (replaces the random stub for
PDF uploads). Implements spec sections 6.4 (extraction) and 6.5
(classification) for exactly one input type: vector PDFs exported "to
scale" from CAD (text and lines are real PDF objects, not a raster image).

Design choices, stated plainly:

1. UNIT CONVERSION IS DETERMINISTIC, NOT AI. A vector PDF page is measured
   in points (1/72 inch). If the drawing was plotted at a known scale
   (e.g. 1:100), then real-world size = page size × (25.4/72) mm × scale.
   This is exact arithmetic, not a model guess — accuracy depends entirely
   on the caller supplying the correct plot scale for the sheet.

2. CLASSIFICATION IS RULE-BASED, WITH TWO TIERS OF CONFIDENCE:
   - A shape whose nearby text matches a known label pattern (e.g. "C1",
     "COL", "WALL") is classified with high confidence.
   - A shape with no matching label is classified only by geometry
     (aspect ratio, size) as a fallback, and is deliberately given LOW
     confidence — this is what routes it to the human review queue rather
     than silently guessing. This mirrors spec section 11's guardrail:
     "Rules take precedence... low-confidence results require review."

3. NOTHING HERE CLAIMS TO BE ERROR-FREE. Overlapping shapes, drawings not
   plotted to scale, non-standard labeling conventions, or text that isn't
   near its shape will still produce low-confidence or missed elements.
   That is why every element keeps its source PDF coordinates
   (`source_reference`) for traceability back to the sheet.
"""
import math
from dataclasses import dataclass, field

import pymupdf as fitz  # PyMuPDF

PT_TO_MM = 25.4 / 72.0  # 1 PDF point = 1/72 inch

# label keyword -> element class. Checked as a substring/prefix match
# against text found near each shape (case-insensitive).
LABEL_RULES: list[tuple[str, str]] = [
    ("WALL", "wall"),
    ("WL-", "wall"),
    ("COLUMN", "column"),
    ("COL-", "column"),
    ("COL.", "column"),
    ("SLAB", "slab"),
    ("SL-", "slab"),
    ("BEAM", "beam"),
    ("BM-", "beam"),
    ("FOOTING", "footing"),
    ("FTG", "footing"),
]
# Generic short codes like "C1", "B2", "F3", "W4" (prefix letter + digits)
PREFIX_CLASS = {"C": "column", "B": "beam", "F": "footing", "W": "wall", "S": "slab"}

LABEL_SEARCH_RADIUS_PT = 40  # how far (in PDF points) to look for a label near a shape

# Geometry fallback thresholds, in real-world mm / sqm — used ONLY when no
# text label is found near a shape. Deliberately conservative.
WALL_MAX_THICKNESS_MM = 350
WALL_MIN_ASPECT = 4.0
COLUMN_MAX_AREA_M2 = 1.0
COLUMN_MAX_ASPECT = 1.8


@dataclass
class RawShape:
    x0: float
    y0: float
    x1: float
    y1: float
    filled: bool
    page_number: int
    page_w: float = 0.0
    page_h: float = 0.0

    @property
    def width_pt(self) -> float:
        return abs(self.x1 - self.x0)

    @property
    def height_pt(self) -> float:
        return abs(self.y1 - self.y0)

    @property
    def center(self) -> tuple[float, float]:
        return ((self.x0 + self.x1) / 2, (self.y0 + self.y1) / 2)


@dataclass
class TextToken:
    x0: float
    y0: float
    x1: float
    y1: float
    text: str
    page_number: int

    @property
    def center(self) -> tuple[float, float]:
        return ((self.x0 + self.x1) / 2, (self.y0 + self.y1) / 2)


@dataclass
class ExtractedElement:
    element_class: str
    quantity_type: str  # "length" | "area"
    value: float
    unit: str
    confidence: float
    source_reference: str
    matched_label: str | None = None
    # Location on the sheet, in PDF points, so every element can be drawn
    # back onto the drawing for manual checking (see routers/jobs.py overlay).
    page_number: int = 1
    bbox: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0)
    page_w: float = 0.0
    page_h: float = 0.0


@dataclass
class ExtractionResult:
    elements: list[ExtractedElement]
    raw_shapes: int = 0
    dropped_page_frame: int = 0
    dropped_line_noise: int = 0
    dropped_duplicates: int = 0
    dropped_unclassified: int = 0
    dropped_tiny: int = 0


# Noise filters for real-world sheets (hatching, grid lines, dimension lines,
# title-block frames, nested duplicate outlines).
FRAME_FRACTION = 0.95        # a shape spanning >=95% of both page sides is the sheet border
LINE_MAX_THICKNESS_PT = 1.5  # thinner than this AND very elongated = a drawn line, not an element
LINE_MIN_ASPECT = 25.0
DUPLICATE_IOU = 0.85         # near-identical boxes (double-stroked outlines) count once


def _iou(a: RawShape, b: RawShape) -> float:
    ix = max(0.0, min(a.x1, b.x1) - max(a.x0, b.x0))
    iy = max(0.0, min(a.y1, b.y1) - max(a.y0, b.y0))
    inter = ix * iy
    union = a.width_pt * a.height_pt + b.width_pt * b.height_pt - inter
    return inter / union if union > 0 else 0.0


def _filter_noise(shapes: list[RawShape]) -> tuple[list[RawShape], int, int, int]:
    frame = line = dup = 0
    kept: list[RawShape] = []
    for s in shapes:
        if s.page_w and s.width_pt >= FRAME_FRACTION * s.page_w and s.height_pt >= FRAME_FRACTION * s.page_h:
            frame += 1
            continue
        thin = min(s.width_pt, s.height_pt)
        long_ = max(s.width_pt, s.height_pt)
        if thin <= LINE_MAX_THICKNESS_PT and long_ / max(thin, 1e-6) >= LINE_MIN_ASPECT:
            line += 1
            continue
        kept.append(s)

    # O(n) duplicate removal: boxes whose edges agree to within ~1pt are the
    # same outline stroked twice (common in CAD exports).
    seen: set[tuple[int, int, int, int, int]] = set()
    unique: list[RawShape] = []
    for s in kept:
        key = (s.page_number, round(s.x0), round(s.y0), round(s.x1), round(s.y1))
        if key in seen:
            dup += 1
            continue
        seen.add(key)
        unique.append(s)
    return unique, frame, line, dup


def _distance(p1: tuple[float, float], p2: tuple[float, float]) -> float:
    return math.hypot(p1[0] - p2[0], p1[1] - p2[1])


def parse_pdf_geometry(pdf_path: str) -> tuple[list[RawShape], list[TextToken]]:
    """Extracts vector paths (as bounding-box shapes) and text tokens from
    every page of the PDF. Curves/complex paths are approximated by their
    bounding box, which is sufficient for rectangular civil/structural
    elements (walls, columns, slabs, beams, footings in plan view)."""
    doc = fitz.open(pdf_path)
    shapes: list[RawShape] = []
    tokens: list[TextToken] = []

    for page_index, page in enumerate(doc):
        for drawing in page.get_drawings():
            rect = drawing["rect"]
            if rect.width < 0.5 or rect.height < 0.5:
                continue  # skip degenerate/zero-size paths (hairlines, dots)
            shapes.append(
                RawShape(
                    x0=rect.x0, y0=rect.y0, x1=rect.x1, y1=rect.y1,
                    filled=bool(drawing.get("fill")),
                    page_number=page_index + 1,
                    page_w=page.rect.width, page_h=page.rect.height,
                )
            )
        for x0, y0, x1, y1, word, *_ in page.get_text("words"):
            tokens.append(
                TextToken(x0=x0, y0=y0, x1=x1, y1=y1, text=word, page_number=page_index + 1)
            )

    doc.close()
    return shapes, tokens


def _classify_by_label(label: str) -> tuple[str, float] | None:
    upper = label.upper()
    for keyword, klass in LABEL_RULES:
        if keyword in upper:
            return klass, 0.95
        # Tolerates text clipped at a page/viewport edge, e.g. "WALL" -> "WAL"
        if len(upper) >= 3 and keyword.startswith(upper):
            return klass, 0.80
    if len(upper) >= 2 and upper[0] in PREFIX_CLASS and upper[1:].replace("-", "").isdigit():
        return PREFIX_CLASS[upper[0]], 0.88
    return None


def _assign_labels(shapes: list[RawShape], tokens: list[TextToken]) -> dict[int, str]:
    """
    Greedily assigns each shape its nearest AVAILABLE text label, processing
    smallest shapes first and removing a label from the pool once claimed.

    Rationale: naive "nearest label by raw distance" breaks down whenever a
    large background shape (e.g. a slab spanning the whole sheet) has a
    smaller labeled element (e.g. a beam) sitting inside it — the smaller
    element's own label is often geometrically closest to the *big* shape's
    centroid too, so the big shape would otherwise steal it. Processing
    small-to-large and removing consumed labels lets specific, local
    elements claim their own labels first.
    """
    order = sorted(range(len(shapes)), key=lambda i: shapes[i].width_pt * shapes[i].height_pt)
    available = list(tokens)
    assignment: dict[int, str] = {}

    for idx in order:
        shape = shapes[idx]
        same_page = [t for t in available if t.page_number == shape.page_number]
        if not same_page:
            continue
        nearest = min(same_page, key=lambda t: _distance(shape.center, t.center))
        if _distance(shape.center, nearest.center) <= LABEL_SEARCH_RADIUS_PT:
            assignment[idx] = nearest.text
            available.remove(nearest)

    return assignment


def _classify_by_geometry(width_mm: float, height_mm: float, area_m2: float) -> tuple[str, float]:
    """Fallback used only when no text label is found near the shape.
    Deliberately low confidence — routes to human review rather than
    silently guessing (spec section 11)."""
    long_side = max(width_mm, height_mm)
    short_side = max(min(width_mm, height_mm), 1e-6)
    aspect = long_side / short_side

    if aspect >= WALL_MIN_ASPECT and short_side <= WALL_MAX_THICKNESS_MM:
        return "wall", 0.55
    if aspect <= COLUMN_MAX_ASPECT and area_m2 <= COLUMN_MAX_AREA_M2:
        return "column", 0.55
    if area_m2 > COLUMN_MAX_AREA_M2:
        return "slab", 0.45
    return "unclassified", 0.30


MIN_ELEMENT_AREA_M2 = 0.02  # ~140mm x 140mm: smaller real-world shapes are symbols/arrowheads/hatch ticks


def extract(pdf_path: str, scale_ratio: float) -> ExtractionResult:
    """
    scale_ratio: the drawing's plot scale denominator (e.g. 100 for a
    1:100 drawing). Must reflect the actual scale the sheet was plotted
    at — this is the single most important input for accuracy, since the
    geometry math is otherwise exact.
    """
    raw_shapes, tokens = parse_pdf_geometry(pdf_path)
    shapes, n_frame, n_line, n_dup = _filter_noise(raw_shapes)
    mm_per_pt = PT_TO_MM * scale_ratio
    label_assignment = _assign_labels(shapes, tokens)

    result = ExtractionResult(
        elements=[], raw_shapes=len(raw_shapes),
        dropped_page_frame=n_frame, dropped_line_noise=n_line, dropped_duplicates=n_dup,
    )
    for idx, shape in enumerate(shapes):
        width_mm = shape.width_pt * mm_per_pt
        height_mm = shape.height_pt * mm_per_pt
        area_m2 = (width_mm / 1000) * (height_mm / 1000)

        if area_m2 < MIN_ELEMENT_AREA_M2:
            result.dropped_tiny += 1
            continue

        label = label_assignment.get(idx)
        classification = _classify_by_label(label) if label else None
        from_label = classification is not None
        if classification is None:
            classification = _classify_by_geometry(width_mm, height_mm, area_m2)
        element_class, confidence = classification

        # A large, unfilled box with no label nearby is almost always an annotation
        # frame (title block, viewport, note box), not a slab — don't guess.
        if not from_label and not shape.filled and element_class == "slab":
            element_class = "unclassified"

        if element_class == "unclassified":
            result.dropped_unclassified += 1
            continue

        is_wall = element_class == "wall"
        quantity_type = "length" if is_wall else "area"
        # Walls: report the long side as running length (typical BOQ measure for walls).
        # Columns/slabs/beams/footings: report plan area.
        value = max(width_mm, height_mm) / 1000 if is_wall else area_m2
        unit = "m" if is_wall else "sqm"

        result.elements.append(
            ExtractedElement(
                element_class=element_class,
                quantity_type=quantity_type,
                value=round(value, 4),
                unit=unit,
                confidence=confidence,
                source_reference=f"page-{shape.page_number}/x{int(shape.x0)},y{int(shape.y0)}",
                matched_label=label if from_label else None,
                page_number=shape.page_number,
                bbox=(shape.x0, shape.y0, shape.x1, shape.y1),
                page_w=shape.page_w, page_h=shape.page_h,
            )
        )
    return result


def extract_elements(pdf_path: str, scale_ratio: float) -> list[ExtractedElement]:
    return extract(pdf_path, scale_ratio).elements
