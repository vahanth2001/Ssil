"""
Deterministic BOQ & Cost Engine (spec section 6.7, 10).

Design principle carried over from the spec: "AI interprets drawings and
documents; deterministic services perform engineering and commercial
calculations." This module never calls an LLM — it maps extracted
Elements to catalogue rates using plain decimal arithmetic, exactly the
guardrail the spec calls for in section 10 ("floating-point binary
arithmetic must not be used for contractual totals").
"""
from decimal import Decimal, ROUND_HALF_UP

from sqlalchemy.orm import Session

from ..models import BOQCatalogueItem, BOQLine, Element, OutputStatus


# Very small deterministic mapping from extracted element class to a
# catalogue item code. In the full platform this comes from the
# tenant-configurable "Element-to-BOQ mapping" (section 6.7); here it's a
# minimal illustrative default so the pipeline is runnable end-to-end.
DEFAULT_ELEMENT_TO_CODE = {
    "wall": "BOQ-WALL-001",
    "column": "BOQ-COL-001",
    "slab": "BOQ-SLAB-001",
    "beam": "BOQ-BEAM-001",
    "footing": "BOQ-FTG-001",
}

# Elements below this confidence do not get priced automatically. They stay
# visible in the element list (for the reviewer) but are excluded from the
# BOQ until a human confirms them — see spec section 11: "Low-confidence
# results require review" and section 2: "No output is treated as final
# without configurable validation and approval controls."
MIN_CONFIDENCE_FOR_AUTO_BOQ = 0.80


def round_amount(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def generate_boq_lines(db: Session, project_id: str, tenant_id: str, elements: list[Element]) -> list[BOQLine]:
    """
    Maps each extracted Element to a catalogue rate and produces a BOQLine
    with full traceability back to the source element (spec section 2:
    "Every calculated quantity must retain source traceability").
    """
    created: list[BOQLine] = []
    for element in elements:
        if float(element.confidence) < MIN_CONFIDENCE_FOR_AUTO_BOQ:
            continue  # held for human review — not priced automatically (spec §11)

        code = DEFAULT_ELEMENT_TO_CODE.get(element.element_class.lower())
        if not code:
            continue  # unmapped class -> left for human mapping (section 6.7)

        catalogue_item = (
            db.query(BOQCatalogueItem)
            .filter(BOQCatalogueItem.tenant_id == tenant_id, BOQCatalogueItem.code == code)
            .first()
        )
        if not catalogue_item:
            continue  # no rate on file -> commercial validation would flag this (section 16)

        quantity = Decimal(element.value)
        rate = Decimal(catalogue_item.rate)
        amount = round_amount(quantity * rate)

        line = BOQLine(
            project_id=project_id,
            catalogue_item_id=catalogue_item.id,
            element_id=element.id,
            quantity=quantity,
            rate=rate,
            amount=amount,
            status=OutputStatus.PRELIMINARY,
        )
        db.add(line)
        created.append(line)

    db.flush()
    return created
