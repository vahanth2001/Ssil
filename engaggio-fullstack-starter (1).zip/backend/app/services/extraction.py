"""
Extraction / Classification dispatcher (spec sections 6.4, 6.5, 11).

Routes each document to a real extractor based on file type. Only vector
PDF has a real implementation right now (see extraction_pdf.py). Other
formats fall back to a clearly-labeled stub so the rest of the pipeline —
classification -> quantity -> BOQ -> review — stays runnable while real
CAD/BIM adapters (DWG/DXF/IFC) are built.
"""
import random
from decimal import Decimal

from sqlalchemy.orm import Session

from ..models import Document, Element, Job
from . import extraction_pdf

SAMPLE_CLASSES = [
    ("wall", "length", "m"),
    ("column", "area", "sqm"),
    ("slab", "area", "sqm"),
    ("beam", "area", "sqm"),
    ("footing", "area", "sqm"),
]


def run_extraction(db: Session, job: Job, document: Document) -> list[Element]:
    file_name = (document.file_name or "").lower()

    if file_name.endswith(".pdf"):
        return _run_pdf_extraction(db, job, document)

    # DWG/DXF/IFC and any other format: no real adapter yet.
    return _run_stub_extraction(db, job, warn_unsupported=True)


def _run_pdf_extraction(db: Session, job: Job, document: Document) -> list[Element]:
    result = extraction_pdf.extract(document.file_path, scale_ratio=document.scale_ratio or 100)
    raw_elements = result.elements
    job.warnings = (
        f"Read {result.raw_shapes} vector shapes; ignored {result.dropped_page_frame} sheet border, "
        f"{result.dropped_line_noise} line/grid/dimension strokes, {result.dropped_duplicates} duplicate outlines, "
        f"{result.dropped_tiny} symbol-sized marks and {result.dropped_unclassified} unrecognisable shapes; "
        f"kept {len(raw_elements)} elements."
    )
    elements: list[Element] = []
    for raw in raw_elements:
        element = Element(
            job_id=job.id,
            element_class=raw.element_class,
            quantity_type=raw.quantity_type,
            value=Decimal(str(raw.value)),
            unit=raw.unit,
            confidence=Decimal(str(raw.confidence)),
            source_reference=raw.source_reference,
            matched_label=raw.matched_label,
            page_number=raw.page_number,
            bbox_x0=raw.bbox[0], bbox_y0=raw.bbox[1], bbox_x1=raw.bbox[2], bbox_y1=raw.bbox[3],
            page_width=raw.page_w, page_height=raw.page_h,
        )
        db.add(element)
        elements.append(element)
    db.flush()
    return elements


def _run_stub_extraction(db: Session, job: Job, warn_unsupported: bool = False) -> list[Element]:
    """Synthesizes a plausible element set for formats without a real
    adapter yet (DWG/DXF/IFC). NOT derived from the actual file contents —
    every element is flagged with a note in source_reference so this can
    never be mistaken for a real measurement."""
    rng = random.Random(job.id)  # deterministic per job for reproducibility
    elements: list[Element] = []
    for i, (klass, qty_type, unit) in enumerate(SAMPLE_CLASSES):
        value = Decimal(str(round(rng.uniform(5, 250), 2)))
        element = Element(
            job_id=job.id,
            element_class=klass,
            quantity_type=qty_type,
            value=value,
            unit=unit,
            confidence=Decimal("0.0"),  # forces review — this is placeholder data, not a real reading
            source_reference=f"UNSUPPORTED FORMAT — placeholder, not extracted from file (item {i})",
        )
        db.add(element)
        elements.append(element)
    db.flush()
    if warn_unsupported:
        job.warnings = (
            (job.warnings + " " if job.warnings else "")
            + "This file format has no real extraction adapter yet; showing placeholder elements only."
        )
    return elements
