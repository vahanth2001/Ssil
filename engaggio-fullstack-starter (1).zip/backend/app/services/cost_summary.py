"""
Final cost estimate (spec section 6.7: "Currency, tax, overhead, profit,
escalation and contingency settings").

The BOQ engine (boq_engine.py) produces a raw direct-cost sum: quantity x
rate, nothing else. That is NOT a number you'd quote to a client — it's
missing overhead, profit margin, contingency, and tax. This module applies
those as a sequential cascade, in the order a quantity surveyor actually
builds an estimate:

    Direct Cost (raw BOQ sum)
    + Overhead      (% of direct cost)          -> Subtotal 1
    + Profit        (% of Subtotal 1)            -> Subtotal 2
    + Contingency   (% of Subtotal 2)             -> Subtotal 3
    + Tax           (% of Subtotal 3)              -> GRAND TOTAL

Each step is returned separately (not just the final number) so the
breakdown stays traceable back to the assumptions used, per spec section 2:
"Every calculated quantity must retain source traceability... to formula."
Every percentage defaults to 0, so a project with no markups configured
correctly shows Grand Total == Direct Cost rather than silently applying
made-up figures.
"""
from decimal import Decimal, ROUND_HALF_UP

from ..models import Project


def _round(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def compute_cost_summary(project: Project, direct_cost: Decimal) -> dict:
    overhead_pct = Decimal(project.overhead_percent or 0)
    profit_pct = Decimal(project.profit_percent or 0)
    contingency_pct = Decimal(project.contingency_percent or 0)
    tax_pct = Decimal(project.tax_percent or 0)

    overhead_amount = _round(direct_cost * overhead_pct / 100)
    subtotal_1 = direct_cost + overhead_amount

    profit_amount = _round(subtotal_1 * profit_pct / 100)
    subtotal_2 = subtotal_1 + profit_amount

    contingency_amount = _round(subtotal_2 * contingency_pct / 100)
    subtotal_3 = subtotal_2 + contingency_amount

    tax_amount = _round(subtotal_3 * tax_pct / 100)
    grand_total = subtotal_3 + tax_amount

    return {
        "currency": project.currency,
        "direct_cost": direct_cost,
        "overhead_percent": overhead_pct,
        "overhead_amount": overhead_amount,
        "subtotal_after_overhead": subtotal_1,
        "profit_percent": profit_pct,
        "profit_amount": profit_amount,
        "subtotal_after_profit": subtotal_2,
        "contingency_percent": contingency_pct,
        "contingency_amount": contingency_amount,
        "subtotal_after_contingency": subtotal_3,
        "tax_percent": tax_pct,
        "tax_amount": tax_amount,
        "grand_total": grand_total,
    }
