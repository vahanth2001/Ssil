from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, EmailStr, ConfigDict


# ---------- Auth ----------
class TenantSignup(BaseModel):
    tenant_name: str
    admin_email: EmailStr
    admin_full_name: str
    password: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    email: str
    full_name: str
    role: str
    tenant_id: str


# ---------- Projects ----------
class ProjectCreate(BaseModel):
    name: str
    location: Optional[str] = None
    project_type: str = "general"
    units: str = "metric"
    currency: str = "USD"


class ProjectOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    location: Optional[str]
    project_type: str
    units: str
    currency: str
    status: str
    overhead_percent: Decimal
    profit_percent: Decimal
    contingency_percent: Decimal
    tax_percent: Decimal
    created_at: datetime


class CostSettingsUpdate(BaseModel):
    overhead_percent: Decimal = Decimal("0")
    profit_percent: Decimal = Decimal("0")
    contingency_percent: Decimal = Decimal("0")
    tax_percent: Decimal = Decimal("0")


# ---------- Documents ----------
class DocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    file_name: str
    discipline: str
    document_number: Optional[str]
    revision: str
    scale_ratio: int
    status: str
    uploaded_at: datetime


# ---------- Jobs ----------
class ProcessRequest(BaseModel):
    outputs: list[str] = ["quantities", "boq"]


class JobOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    document_id: str
    status: str
    progress: int
    correlation_id: str
    warnings: str
    errors: str
    updated_at: datetime


# ---------- Elements & BOQ ----------
class ElementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    element_class: str
    quantity_type: str
    value: Decimal
    unit: str
    confidence: Decimal
    source_reference: str
    matched_label: Optional[str] = None
    page_number: Optional[int] = None
    bbox_x0: Optional[float] = None
    bbox_y0: Optional[float] = None
    bbox_x1: Optional[float] = None
    bbox_y1: Optional[float] = None
    page_width: Optional[float] = None
    page_height: Optional[float] = None


class CatalogueItemCreate(BaseModel):
    code: str
    description: str
    unit: str
    trade: str = "general"
    rate: Decimal
    currency: str = "USD"


class CatalogueItemOut(CatalogueItemCreate):
    model_config = ConfigDict(from_attributes=True)
    id: str


class BOQLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    catalogue_item_id: str
    element_id: Optional[str]
    quantity: Decimal
    rate: Decimal
    amount: Decimal
    status: str


class BOQSummaryOut(BaseModel):
    project_id: str
    currency: str
    line_count: int
    total_amount: Decimal
    lines: list[BOQLineOut]


class CostSummaryOut(BaseModel):
    currency: str
    direct_cost: Decimal
    overhead_percent: Decimal
    overhead_amount: Decimal
    subtotal_after_overhead: Decimal
    profit_percent: Decimal
    profit_amount: Decimal
    subtotal_after_profit: Decimal
    contingency_percent: Decimal
    contingency_amount: Decimal
    subtotal_after_contingency: Decimal
    tax_percent: Decimal
    tax_amount: Decimal
    grand_total: Decimal
