"""Generates a synthetic to-scale vector PDF floor plan to validate the extraction engine."""
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor

c = canvas.Canvas("/tmp/sample_floorplan.pdf", pagesize=(600, 400))

# Slab (whole floor plate)
c.setFillColor(HexColor("#dddddd"))
c.rect(20, 20, 560, 360, fill=1, stroke=1)
c.setFillColor(HexColor("#000000"))
c.drawString(280, 260, "SLAB")

# Perimeter walls (long thin rectangles), labeled
c.setFillColor(HexColor("#333333"))
c.rect(20, 370, 560, 10, fill=1, stroke=0)   # top wall
c.drawString(290, 372, "WALL")
c.rect(20, 20, 10, 360, fill=1, stroke=0)    # left wall
c.drawString(5, 200, "WALL")
c.rect(570, 20, 10, 360, fill=1, stroke=0)   # right wall
c.drawString(575, 200, "WALL")
c.rect(20, 20, 560, 10, fill=1, stroke=0)    # bottom wall
c.drawString(290, 5, "WL-01")

# Columns (small squares), labeled with generic codes
cols = [(60, 60), (540, 60), (60, 340), (540, 340), (300, 200)]
for i, (x, y) in enumerate(cols, start=1):
    c.setFillColor(HexColor("#555555"))
    c.rect(x, y, 12, 12, fill=1, stroke=0)
    c.setFillColor(HexColor("#000000"))
    c.drawString(x - 2, y + 14, f"C{i}")

# Beams (medium rectangles), labeled
c.setFillColor(HexColor("#777777"))
c.rect(60, 190, 480, 8, fill=1, stroke=0)
c.drawString(280, 178, "BEAM")

# Footings, labeled — placed at a clearly separate location, not stacked on a column
c.setFillColor(HexColor("#999999"))
c.rect(250, 60, 22, 22, fill=1, stroke=0)
c.drawString(245, 50, "F1")

# One unlabeled ambiguous shape far from any text -> should go to review
c.setFillColor(HexColor("#bbbbbb"))
c.rect(150, 280, 18, 15, fill=1, stroke=0)

c.showPage()
c.save()
print("Generated /tmp/sample_floorplan.pdf")
